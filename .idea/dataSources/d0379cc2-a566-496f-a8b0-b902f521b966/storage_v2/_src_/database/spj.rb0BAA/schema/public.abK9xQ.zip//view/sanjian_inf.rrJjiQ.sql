create view sanjian_inf as
  SELECT spj.sno, spj.pno, spj.qty
  FROM j,
       spj
  WHERE (((j.jname) :: text = '三建' :: text) AND (spj.jno = j.jno));

alter table sanjian_inf
  owner to postgres;

